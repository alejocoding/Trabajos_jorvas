#Crear un SCRIPT con requerimientos funcionales, no funcionales para un sistema de 
#reservas de hotel que permita a los usuarios reservar habitaciones, verificando la disponibilidad para 
#las fechas seleccionadas.

from datetime import datetime
import calendar
dia = 0 

print("                                               Bienvenido al Hotel")
seleccion = input("Digite 1 Para para reserva ")


match seleccion:

    case "1":
        h = int(input(" Digite el numero de huespedes (maximo 2)"))
        while True:
            if h == 1:
                
                mes = int(input("Digite el mes para ver la disponibilidad del cuarto: "))
                c = calendar.TextCalendar(calendar.SUNDAY)
                #Mes numero 1
                if mes == 1:  
                    calendario = c.formatmonth(2024, mes)
                    print(calendario)
                    dia = int(input("Digite el dia que quiere la reserva: "))

                    while dia==1 or dia==2 or dia==5 or dia==6 or dia==9 or dia==11 or dia==12 or dia==16 or dia==18 or dia==20 or dia==23 or dia==25 or dia==28 or dia==30:
                        print(" En este dia el cuarto no se encuentra disponible.")
                        print(calendario)
                        dia = int(input("Elija otro dia:"))
                
                    print("El caurto cuenta con horarios de 12 horas ")
                    print(" 1. 5:00 Am - 5:00 Pm ""      2. 5:00 Pm - 5:00 Am")
                    h = int(input("Seleccione el horario: "))
                    if h == 1:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:ENERO Dia:",dia, "Hora: 5:00 Am - 5:00 Pm")
                        
                    if h == 2:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:ENERO Dia:",dia, "Hora: 5:00 Pm - 5:00 m")
                            

                # Mes numero 2
                if mes == 2:
                    print("ESTE MES NO ESTA DISPONIBLE")
                    bool(False)
                    
                
                # Mes nuemro 3
                if mes == 3: 
                    calendario = c.formatmonth(2024, mes)
                    print(calendario)
                    dia = int(input("Digite el dia que quiere la reserva: "))

                    while dia==1 or dia==2 or dia==5 or dia==6 or dia==9 or dia==11 or dia==12 or dia==16 or dia==18 or dia==20 or dia==23 or dia==25 or dia==28 or dia==30:
                        print(" En este dia el cuarto no se encuentra disponible.")
                        print(calendario)
                        dia = int(input("Elija otro dia:"))
                
                    print("El caurto cuenta con horarios de 12 horas ")
                    print(" 1. 5:00 Am - 5:00 Pm ""      2. 5:00 Pm - 5:00 Am")
                    h = int(input("Seleccione el horario: "))
                    if h == 1:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:MARZO Dia:",dia, "Hora: 5:00 Am - 5:00 Pm")
                        
                    if h == 2:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:MARZO Dia:",dia, "Hora: 5:00 Pm - 5:00 m")
                # Mes Numero 4
                if mes == 4:
                    print(" Mes no disponible")
                    bool(False)
                # Mes nuemero 5
                if mes == 5:
                    print(" Mes no disponible")
                    bool(False)
                # Mes numero 6
                if mes == 6:
                    print(" Mes no disponible")
                    bool(False)
                # Mes nuemero 7
                if mes == 7:
                    calendario = c.formatmonth(2024, mes)
                    print(calendario)
                    dia = int(input("Digite el dia que quiere la reserva: "))

                    while dia==1 or dia==2 or dia==5 or dia==6 or dia==9 or dia==11 or dia==12 or dia==16 or dia==18 or dia==20 or dia==23 or dia==25 or dia==28 or dia==30:
                        print(" En este dia el cuarto no se encuentra disponible.")
                        print(calendario)
                        dia = int(input("Elija otro dia:"))
                
                    print("El caurto cuenta con horarios de 12 horas ")
                    print(" 1. 5:00 Am - 5:00 Pm ""      2. 5:00 Pm - 5:00 Am")
                    h = int(input("Seleccione el horario: "))
                    if h == 1:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:Julio Dia:",dia, "Hora: 5:00 Am - 5:00 Pm")
                        
                    if h == 2:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:Julio Dia:",dia, "Hora: 5:00 Pm - 5:00 m")
                
                # Mes numero 8
                if mes == 8:
                    calendario = c.formatmonth(2024, mes)
                    print(calendario)
                    dia = int(input("Digite el dia que quiere la reserva: "))

                    while dia==1 or dia==2 or dia==5 or dia==6 or dia==9 or dia==11 or dia==12 or dia==16 or dia==18 or dia==20 or dia==23 or dia==25 or dia==28 or dia==30:
                        print(" En este dia el cuarto no se encuentra disponible.")
                        print(calendario)
                        dia = int(input("Elija otro dia:"))
                
                    print("El caurto cuenta con horarios de 12 horas ")
                    print(" 1. 5:00 Am - 5:00 Pm ""      2. 5:00 Pm - 5:00 Am")
                    h = int(input("Seleccione el horario: "))
                    if h == 1:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:Agosto Dia:",dia, "Hora: 5:00 Am - 5:00 Pm")
                        
                    if h == 2:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:Agosto Dia:",dia, "Hora: 5:00 Pm - 5:00 m")

                # Mes numero 9
                if mes == 9: 
                    print("Mes no disponible")
                    bool(False)

                # Mes numero 10 
                if mes == 10:
                    calendario = c.formatmonth(2024, mes)
                    print(calendario)
                    dia = int(input("Digite el dia que quiere la reserva: "))

                    while dia==1 or dia==2 or dia==5 or dia==6 or dia==9 or dia==11 or dia==12 or dia==16 or dia==18 or dia==20 or dia==23 or dia==25 or dia==28 or dia==30:
                        print(" En este dia el cuarto no se encuentra disponible.")
                        print(calendario)
                        dia = int(input("Elija otro dia:"))
                
                    print("El caurto cuenta con horarios de 12 horas ")
                    print(" 1. 5:00 Am - 5:00 Pm ""      2. 5:00 Pm - 5:00 Am")
                    h = int(input("Seleccione el horario: "))
                    if h == 1:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:Octubre Dia:",dia, "Hora: 5:00 Am - 5:00 Pm")
                        
                    if h == 2:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:Octubre Dia:",dia, "Hora: 5:00 Pm - 5:00 m")

                # Mes numero 11
                if mes == 11:
                    print(" Mes no disponible")
                    bool(False)

                # Mes numero 12
                if mes == 12:
                    calendario = c.formatmonth(2024, mes)
                    print(calendario)
                    dia = int(input("Digite el dia que quiere la reserva: "))

                    while dia==1 or dia==2 or dia==5 or dia==6 or dia==9 or dia==11 or dia==12 or dia==16 or dia==18 or dia==20 or dia==23 or dia==25 or dia==28 or dia==30:
                        print(" En este dia el cuarto no se encuentra disponible.")
                        print(calendario)
                        dia = int(input("Elija otro dia:"))
                
                    print("El caurto cuenta con horarios de 12 horas ")
                    print(" 1. 5:00 Am - 5:00 Pm ""      2. 5:00 Pm - 5:00 Am")
                    h = int(input("Seleccione el horario: "))
                    if h == 1:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:Diciembre Dia:",dia, "Hora: 5:00 Am - 5:00 Pm")
                        
                    if h == 2:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:Diciembre Dia:",dia, "Hora: 5:00 Pm - 5:00 m")

            break
    case "2":
        h = int(input(" Digite el numero de huespedes (maximo 2)"))
        while True:
            if h == 1:
                
                mes = int(input("Digite el mes para ver la disponibilidad del cuarto: "))
                c = calendar.TextCalendar(calendar.SUNDAY)
                #Mes numero 1
                if mes == 1:  
                    calendario = c.formatmonth(2024, mes)
                    print(calendario)
                    dia = int(input("Digite el dia que quiere la reserva: "))

                    while dia==2 or dia==5 or dia==6 or dia==9 or dia==11 or dia==12 or dia==18 or dia==20 or dia==23 or dia==25 or dia==28 or dia==30:
                        print(" En este dia el cuarto no se encuentra disponible.")
                        print(calendario)
                        dia = int(input("Elija otro dia:"))
                
                    print("El caurto cuenta con horarios de 12 horas ")
                    print(" 1. 5:00 Am - 5:00 Pm ""      2. 5:00 Pm - 5:00 Am")
                    h = int(input("Seleccione el horario: "))
                    if h == 1:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:ENERO Dia:",dia, "Hora: 5:00 Am - 5:00 Pm")
                        
                    if h == 2:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:ENERO Dia:",dia, "Hora: 5:00 Pm - 5:00 m")
                            

                # Mes numero 2
                if mes == 2:
                    print("ESTE MES NO ESTA DISPONIBLE")
                    bool(False)
                
                # Mes nuemro 3
                if mes == 3: 
                    calendario = c.formatmonth(2024, mes)
                    print(calendario)
                    dia = int(input("Digite el dia que quiere la reserva: "))

                    while dia==1 or dia==5 or dia==6 or dia==9 or dia==11 or dia==16 or dia==18 or dia==20 or dia==23 or dia==28 or dia==30:
                        print(" En este dia el cuarto no se encuentra disponible.")
                        print(calendario)
                        dia = int(input("Elija otro dia:"))
                
                    print("El caurto cuenta con horarios de 12 horas ")
                    print(" 1. 5:00 Am - 5:00 Pm ""      2. 5:00 Pm - 5:00 Am")
                    h = int(input("Seleccione el horario: "))
                    if h == 1:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:MARZO Dia:",dia, "Hora: 5:00 Am - 5:00 Pm")
                        
                    if h == 2:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:MARZO Dia:",dia, "Hora: 5:00 Pm - 5:00 m")
                # Mes Numero 4
                if mes == 4:
                    print(" Mes no disponible")
                    bool(False)
                # Mes nuemero 5
                if mes == 5:
                    print(" Mes no disponible")
                    bool(False)
                # Mes numero 6
                if mes == 6:
                    print(" Mes no disponible")
                    bool(False)
                # Mes nuemero 7
                if mes == 7:
                    calendario = c.formatmonth(2024, mes)
                    print(calendario)
                    dia = int(input("Digite el dia que quiere la reserva: "))

                    while dia==1 or dia==2 or dia==5 or dia==6 or dia==9 or dia==11 or dia==25 or dia==28 or dia==30:
                        print(" En este dia el cuarto no se encuentra disponible.")
                        print(calendario)
                        dia = int(input("Elija otro dia:"))
                
                    print("El caurto cuenta con horarios de 12 horas ")
                    print(" 1. 5:00 Am - 5:00 Pm ""      2. 5:00 Pm - 5:00 Am")
                    h = int(input("Seleccione el horario: "))
                    if h == 1:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:Julio Dia:",dia, "Hora: 5:00 Am - 5:00 Pm")
                        
                    if h == 2:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:Julio Dia:",dia, "Hora: 5:00 Pm - 5:00 m")
                
                # Mes numero 8
                if mes == 8:
                    calendario = c.formatmonth(2024, mes)
                    print(calendario)
                    dia = int(input("Digite el dia que quiere la reserva: "))

                    while dia==1 or dia==2 or dia==5 or dia==6 or dia==9 or dia==23 or dia==25 or dia==28 or dia==30:
                        print(" En este dia el cuarto no se encuentra disponible.")
                        print(calendario)
                        dia = int(input("Elija otro dia:"))
                
                    print("El caurto cuenta con horarios de 12 horas ")
                    print(" 1. 5:00 Am - 5:00 Pm ""      2. 5:00 Pm - 5:00 Am")
                    h = int(input("Seleccione el horario: "))
                    if h == 1:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:Agosto Dia:",dia, "Hora: 5:00 Am - 5:00 Pm")
                        
                    if h == 2:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:Agosto Dia:",dia, "Hora: 5:00 Pm - 5:00 m")

                # Mes numero 9
                if mes == 9: 
                    print("Mes no disponible")
                    bool(False)

                # Mes numero 10 
                if mes == 10:
                    calendario = c.formatmonth(2024, mes)
                    print(calendario)
                    dia = int(input("Digite el dia que quiere la reserva: "))

                    while dia==1 or dia==2 or dia==5 or dia==6 or dia==16 or dia==18 or dia==20 or dia==23 or dia==25 or dia==28 or dia==30:
                        print(" En este dia el cuarto no se encuentra disponible.")
                        print(calendario)
                        dia = int(input("Elija otro dia:"))
                
                    print("El caurto cuenta con horarios de 12 horas ")
                    print(" 1. 5:00 Am - 5:00 Pm ""      2. 5:00 Pm - 5:00 Am")
                    h = int(input("Seleccione el horario: "))
                    if h == 1:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:Octubre Dia:",dia, "Hora: 5:00 Am - 5:00 Pm")
                        
                    if h == 2:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:Octubre Dia:",dia, "Hora: 5:00 Pm - 5:00 m")

                # Mes numero 11
                if mes == 11:
                    print(" Mes no disponible")
                    bool(False)

                # Mes numero 12
                if mes == 12:
                    calendario = c.formatmonth(2024, mes)
                    print(calendario)
                    dia = int(input("Digite el dia que quiere la reserva: "))

                    while dia==1 or dia==11 or dia==12 or dia==16 or dia==18 or dia==20 or dia==23 or dia==25 or dia==28 or dia==30:
                        print(" En este dia el cuarto no se encuentra disponible.")
                        print(calendario)
                        dia = int(input("Elija otro dia:"))
                
                    print("El caurto cuenta con horarios de 12 horas ")
                    print(" 1. 5:00 Am - 5:00 Pm ""      2. 5:00 Pm - 5:00 Am")
                    h = int(input("Seleccione el horario: "))
                    if h == 1:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:Diciembre Dia:",dia, "Hora: 5:00 Am - 5:00 Pm")
                        
                    if h == 2:
                        print(" Reserva Exitosa")
                        print("Datos de la reserva: Mes:Diciembre Dia:",dia, "Hora: 5:00 Pm - 5:00 m") 
            break




            
                
            
            
            




            
